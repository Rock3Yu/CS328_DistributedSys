package myrmi;

public interface Remote {
}
