package myrmi.exception;

public class RemoteException extends java.io.IOException {


}
