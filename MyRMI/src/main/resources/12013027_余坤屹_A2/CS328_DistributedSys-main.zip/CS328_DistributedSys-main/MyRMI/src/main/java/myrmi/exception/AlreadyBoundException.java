package myrmi.exception;

public class AlreadyBoundException extends java.lang.Exception {
    public AlreadyBoundException() {
        super();
    }

    public AlreadyBoundException(String s) {
        super(s);
    }
}
